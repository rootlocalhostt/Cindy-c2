# Condi C2 Used Harmony
- you dont know set up?? contact me @zxcr9999 i can help u
- https://ibb.co/PWxk21D Nhóc Ten Khong à, hơi đen cho em rồi đấy đòi bán public source hả em :))
